# Userbot-100101110

[![GitHub followers](https://img.shields.io/github/followers/100101110?label=Followers&style=social)](https://github.com/100101110?tab=followers)
[![GitHub stars](https://img.shields.io/github/stars/100101110/userbot-100101110?style=social)](https://github.com/100101110/userbot-100101110/stars/)
[![GitHub forks](https://img.shields.io/github/forks/100101110/userbot-100101110?style=social)](https://github.com/100101110/userbot-100101110/network/members)
[![GitHub watchers](https://img.shields.io/github/watchers/100101110/userbot-100101110?style=social)](https://github.com/100101110/userbot-100101110/watchers/)

***

[![License: AGPL v3](https://img.shields.io/badge/License-AGPL%20v3-green.svg)](https://www.gnu.org/licenses/agpl-3.0)
[![Repo Size](https://img.shields.io/github/repo-size/100101110/userbot-100101110)](https://github.com/100101110/userbot-100101110 "userbot-10010101110")
[![Made in Python](https://img.shields.io/badge/Made%20in-python-red.svg)](https://www.python.org/)

## INSTALLAZIONE

[![Deploy To Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

### Var Obbligatorie

- Solo queste due variabili sono obbligatorie:
  - `APP_ID`: Valore da ottenere da <https://my.telegram.org>
  - `API_HASH`: Valore da ottenere da <https://my.telegram.org>
- Se non ci sono causerà: `telethon.errors.rpc_error_list.ApiIdPublishedFloodError`

***

#### CONTATTI:

[![Telegram](https://img.shields.io/badge/TG-%20@IOOIOIIIO-orange.svg)](https://t.me/IOOIOIIIO)
[![Github](https://img.shields.io/badge/Github-%20100101110-purple.svg)](https://github.com/100101110)
